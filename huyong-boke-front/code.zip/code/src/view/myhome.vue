<template>
  <div>
    <mybar></mybar>
  </div>
</template>
<script>
import mybar from "./mybar"
export default {
  name : "myhome",
  components : {
    mybar
  }
}
</script>
<style lang="postcss" scoped>

</style>
