<template>
  <nav>
    <div>
      <div class="nav-left">
      <img src="" alt="my nav">
      </div>
    <div class="nav-middle">
      <ul class="nav-ul">
        <li>
          <a href="#">
            <span>
              <font class="font-text">
                发现
              </font>
            </span>
          </a>
        </li>
        <li>
          <a href="#">
            <span >
              <font class="font-text">
                发现
              </font>
            </span>
          </a>
        </li>
        <li>
          <a href="#">
            <span>
              <font class="font-text">
                发现
              </font>
            </span>
          </a>
        </li>
      </ul>
    </div>
    </div>
  </nav>
</template>
<script>
export default {

}
</script>
<style lang="postcss" scoped>
.nav-left{
  display: inline-block;
  margin-right: 5%
}
.nav-middle{
  display: inline-block;
}
.nav-ul{
  display: inline;
}
.nav-ul li{
  list-style: none;
  float: left;
}
a{
  text-decoration: none
}
.font-text{
  padding: 5%
}
</style>
